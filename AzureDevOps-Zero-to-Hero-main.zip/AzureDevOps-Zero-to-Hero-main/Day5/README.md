# 🚀 Azure DevOps Release Pipeline - Continous Delivery of a YouTube Clone Website

## Check out the video below for Day5 👇

[![Day5/16 - Azure DevOps Release Pipeline](https://img.youtube.com/vi/acJErWFS15w/sddefault.jpg)](https://youtu.be/acJErWFS15w)

## Blue Green Deployments

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/dff33415-f7aa-4c35-8389-6c4a5bdfe28d)


## End-to-End CICD Pipeline using Azure DevOps Build and Release Pipeline

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/b3a534f9-9063-49fd-afc4-eb00e133240e)

