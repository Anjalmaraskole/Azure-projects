# Day 14/16 - Azure DevOps Wiki | Azure DevOps Zero to Hero Full Course
## Check out the video below for Day14 👇

[![Day 14/16 - Azure DevOps Wiki | Azure DevOps Zero to Hero Full Course](https://img.youtube.com/vi/j3x-EB9P-6I/sddefault.jpg)](https://youtu.be/j3x-EB9P-6I)
