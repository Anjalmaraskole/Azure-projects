# Day 12/16 - Azure DevOps Advance Security | DevSecOps in Azure DevOps 🔐

## Check out the video below for Day12 👇

[![Day 12/16 - Azure DevOps Advance Security | DevSecOps in Azure DevOps](https://img.youtube.com/vi/G6Fv4B0UQTY/sddefault.jpg)](https://youtu.be/G6Fv4B0UQTY)
