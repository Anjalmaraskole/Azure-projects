# Checkout the video below for explaination of Top 5 deployment strategies

[![Deployment Strategies](https://img.youtube.com/vi/uj0qDN1EWus/sddefault.jpg)](https://youtu.be/uj0qDN1EWus)


## 1) Blue-Green Deployment

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/a0419844-c74e-4478-85e6-8b140aedebc9)

## 2) Canary Release

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/52c40eb0-0320-4e11-ad5e-218f8b98b29d)

## 3) A/B Testing

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/f5f8a929-7e43-4db6-b228-2a59ae45ad4a)

## 4) Rolling Update

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/b3b94b64-e9f1-4bae-ace4-f550960326f3)

## 5) Recreate/All at once

![image](https://github.com/piyushsachdeva/AzureDevOps-Zero-to-Hero/assets/40286378/9eac301c-f9b9-4377-b0f2-10996e44224d)

